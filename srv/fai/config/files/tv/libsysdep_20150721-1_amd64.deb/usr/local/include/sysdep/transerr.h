/*
 *  transerr.h                   (R.Wirowski IKP Uni-Koeln 18-Jun-1993)
 *  ----------
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: transerr.h,v 1.1 1994/05/26 09:23:54 rw Exp rw $
 *
 *  $Log: transerr.h,v $
 * Revision 1.1  1994/05/26  09:23:54  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_TRANSERR_H_
#define _SYSDEP_TRANSERR_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#ifndef _SYSDEP_ERROR_H_
#include <sysdep/error.h>
#endif
#endif

#ifdef _SYSDEP_TRANSERR_C_
#define EXTERN
#else
#define EXTERN extern
#endif


/*
 *  Funktionsdeklarationen:
 */

#ifdef __STDC__
  /*
   * ANSI C
   */
  EXTERN int             send_error(int,int(*)(struct iovec*,int));
  EXTERN int             receive_error(int(*)(void));
  EXTERN int             error_to_string(int,char*,int);
  EXTERN int             string_to_error(const char*);
  

#else  
  /*
   * Traditional C
   */
  EXTERN int             send_error();
  EXTERN int             receive_error();
  EXTERN int             error_to_string();
  EXTERN int             string_to_error();

#endif


#undef EXTERN
#endif  /* _SYSDEP_TRANSERR_H_ */
 
/*
 *  Ende `transerr.h'
 */

	

