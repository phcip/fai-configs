/*
 *  print.h                   (IKP Uni-Koeln 10-May-1992)
 *  -------
 *
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: print.h,v 1.1 1994/05/26 09:19:50 rw Exp rw $
 *
 *  $Log: print.h,v $
 * Revision 1.1  1994/05/26  09:19:50  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_PRINT_H_
#define _SYSDEP_PRINT_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_PRINT_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/*
 *  Typdeklarationen
 */

typedef struct {
#ifdef __STDC__
  int    (*vprintf_msg)(const char*,va_list);  /* must be set */
  int    (*vprintf_err)(const char*,va_list);  /* must be set */
  int    (*puts_msg)(const char*);             /* can be set  */
  int    (*puts_err)(const char*);             /* can be set  */
  int    (*flush_msg)(void);                   /* can be set  */
  int    (*flush_err)(void);                   /* can be set  */
#else
  int    (*vprintf_msg)();                     /* must be set */
  int    (*vprintf_err)();                     /* must be set */
  int    (*puts_msg)();                        /* can be set  */
  int    (*puts_err)();                        /* can be set  */
  int    (*flush_msg)();                       /* can be set  */
  int    (*flush_err)();                       /* can be set  */
#endif
} PRINT_ROUTINES;


/*
 *  Globale Funktionen
 */

#ifdef __STDC__
  /*
   * ANSI C 
   */
  EXTERN int    print_string(int,const char*);
  EXTERN int    print_formatted(int,const char*,...);
  EXTERN int    vprint_formatted(int,const char*,va_list);
  EXTERN int    flush_output(int);
  EXTERN int    set_print_routines(void(*)(PRINT_ROUTINES*));
  EXTERN void   standard_print_routines(PRINT_ROUTINES*);

#else
  /*
   * Traditional C
   */
  EXTERN int    print_string();
  EXTERN int    print_formatted();
  EXTERN int    vprint_formatted();
  EXTERN int    flush_output();
  EXTERN int    set_print_routines();
  EXTERN void   standard_print_routines();

#endif

/*
 *  Makros
 */

#define   PRINT_MSG     (1)
#define   PRINT_ERR     (2)




#undef EXTERN

#endif  /* _SYSDEP_PRINT_ */

/*
 *  Ende 'print.h'
 */
