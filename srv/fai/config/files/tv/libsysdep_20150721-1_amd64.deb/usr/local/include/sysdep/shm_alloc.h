/*
 *  shm_alloc.h                   (R.Wirowski IKP Uni-Koeln 21-Sep-1991)
 *  -----------
 *
 *  Header-File fuer Programme, die die Shared-Memory-Routinen der
 *  Sysdep-Library benutzen. Muss in den entaprechenden Anwenderprogrammen 
 *  'include't werden.
 *
 *  Letzte Aenderung:
 *  -----------------
 *  20-Apr-1992 v1.2 (rw): 'shm_remove()' Routine eingebaut die Shared-Memory-
 *                          Segment und File loescht, wenn Segment frei.
 *
 *  $Id: shm_alloc.h,v 1.1 1994/05/26 12:25:11 rw Exp rw $
 *
 *  $Log: shm_alloc.h,v $
 * Revision 1.1  1994/05/26  12:25:11  rw
 * Initial revision
 *
 *
 */

#ifndef _SYSDEP_SHM_ALLOC_H_
#define _SYSDEP_SHM_ALLOC_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_SHM_ALLOC_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/*
 *  Typedeklaration
 */

typedef struct {
  char         *path;
  unsigned     size;
  int          creator_uid;
  int          creator_gid;
} SYSDEP_SHM_INFO;

/*
 *  Funktionsdeklarationen:
 */

#if defined (__STDC__) && !defined (OSK)
  /*
   * ANSI C 
   */
  EXTERN void  *shm_alloc(unsigned,const char*,int,int);
  EXTERN void  shm_free(void*);
  EXTERN void  shm_free_all();
  EXTERN int   shm_info(void*,SYSDEP_SHM_INFO*);
  EXTERN int   shm_size(const char*);
  EXTERN int   shm_remove(const char*);

#else  /* __STDC__ */  
  /*
   * Traditional C
   */
  EXTERN void  *shm_alloc();
  EXTERN void  shm_free();
  EXTERN void  shm_free_all();
  EXTERN int   shm_info();
  EXTERN int   shm_size();
  EXTERN int   shm_remove();

#endif  /* __STDC__ */

/*
 *  Makrodefinitionen
 */

#define  SHM_FILE_FMT        "shared memory (shm_alloc)\nid=%d\n"
#define  SHM_TESTONLY        ((SYSDEP_SHM_INFO*)-1)
#define  SHM_UNKNOWN_SIZE    (-1)

#define  print_shm_error()   print_formatted(PRINT_ERR,"%s",shm_error)


#undef EXTERN
#endif  /* _SYSDEP_SHM_ALLOC_H_ */

/*
 *  Ende shm_alloc.h
 */

