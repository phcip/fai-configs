/*
 *  cache.h                   (R.Wirowski IKP Uni-Koeln 10-Jul-1992)
 *  -------
 *
 *  $Id: cache.h,v 1.1 1994/05/26 09:14:59 rw Exp rw $
 *
 *  $Log: cache.h,v $
 * Revision 1.1  1994/05/26  09:14:59  rw
 * Initial revision
 *
 *
 */


#ifndef _SYSDEP_CACHE_H_
#define _SYSDEP_CACHE_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_CACHE_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/*
 *  Funktionen
 */

#ifdef __STDC__
  /*
   * ANSI C 
   */
  EXTERN int              set_cache_off(const void*,size_t,int);
  EXTERN int              set_cache_on(const void*);

#else  
  /*
   * Traditional C
   */
  EXTERN int              set_cache_off();
  EXTERN int              set_cache_on();

#endif


/*
 *  Makros
 */

#define OVERLAPPED_PAGES  (0)
#define FULL_PAGES_ONLY   (1) 


#undef EXTERN
#endif  /* _FERA_CACHE_H_ */

/*
 *  Ende cache.h
 */
