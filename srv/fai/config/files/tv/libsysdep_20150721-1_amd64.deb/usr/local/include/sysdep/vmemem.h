/*
 * vmemem.h: Header file for functions used to handle VME memory accesses on
 *           machines which support this
 *
 * $Id: vmemem.h,v 1.2 1994/12/02 15:36:01 nicolay Exp nicolay $
 *
 * $Log: vmemem.h,v $
 * Revision 1.2  1994/12/02  15:36:01  nicolay
 * Presort of channels implemented.
 *
 * Revision 1.1  1994/12/01  14:36:28  nicolay
 * Initial revision
 *
 */

#if !defined(_SYSDEP_VME_H_)
#define _SYSDEP_VMEMEM_H_

#ifdef _SYSDEP_VME_C_
#define EXT
#else
#define EXT extern
#endif

/* copy directions */
#define COPY_TO_VMEMEM   0
#define COPY_FROM_VMEMEM 1

/* VME memory vaild code, used to detect wether the machine was cold booted */
#define VME_MEM_VALID   0x02129103

#if defined(__STDC__)

EXT int  initialize_vme(void);
EXT int  vme_memset(void *s, int c, size_t n);
EXT int  vme_memcpy(void *dest, const void *src, size_t n, int direction);
EXT int  vme_meminc(void *s);
EXT int  vme_memdec(void *s);
EXT int  vme_memsize(void);
EXT int  set_presort_length(int l);
EXT void presort_flush_inc_buffer(void);
EXT void presort_flush_dec_buffer(void);

#else

EXT int initialize_vme();
EXT int  vme_memset();
EXT int  vme_memcpy();
EXT int  vme_meminc();
EXT int  vme_memdec();
EXT int  vme_memsize();
EXT int  set_presort_length();
EXT void presort_flush_inc_buffer(void);
EXT void presort_flush_dec_buffer(void);

#endif

#endif
