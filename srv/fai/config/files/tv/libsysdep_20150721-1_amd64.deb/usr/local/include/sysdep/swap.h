/*
 *  swap.h                   (R.Wirowski IKP Uni-Koeln 15-Sep-1992)
 *  ------
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: swap.h,v 1.1 1994/05/26 09:23:11 rw Exp rw $
 *
 *  $Log: swap.h,v $
 * Revision 1.1  1994/05/26  09:23:11  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_SWAP_H_
#define _SYSDEP_SWAP_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_SWAP_C_
#define EXTERN
#else
#define EXTERN  extern
#endif

/*
 *  Funktionen:
 */

#if defined (__STDC__)
  /*
   * ANSI C 
   */
  EXTERN void     swap_uint16(UINT16*,UINT16*,int);
  EXTERN void     swap_uint32(UINT32*,UINT32*,int);

#else 
  /*
   * Traditional C
   */
  EXTERN void     swap_uint16();
  EXTERN void     swap_uint32();

#endif



/*
 *  Funktionsartige Makros
 */

#define  swap16(s)                                                    \
  ( (UINT16)( ((UINT16)(s) >> 8) | ((UINT16)(s) << 8) ) )

#define  swap32(l)                                                    \
  ( (UINT32)( ( ((UINT32)(l) >> 24) & (UINT32)0x0000ff ) |            \
              ( ((UINT32)(l) >>  8) & (UINT32)0x00ff00 ) |            \
              ( ((UINT32)(l) <<  8) & (UINT32)0xff0000 ) |            \
              ( ((UINT32)(l) << 24) )                    ) )




#undef EXTERN

#endif  /* _SYSDEP_SWAP_H_ */

/*
 *  Ende 'swap.h'
 */
