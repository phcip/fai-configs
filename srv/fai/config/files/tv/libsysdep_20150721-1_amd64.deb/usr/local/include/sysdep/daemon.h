/*
 *  daemon.h                   (R.Wirowski IKP Uni-Koeln 23-May-1993)
 *  --------
 *
 *
 *  $Id: daemon.h,v 1.1 1994/05/26 09:16:35 rw Exp rw $
 *
 *  $Log: daemon.h,v $
 * Revision 1.1  1994/05/26  09:16:35  rw
 * Initial revision
 *
 *
 *
 *
 */

#ifndef _SYSDEP_DAEMON_H_
#define _SYSDEP_DAEMON_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_DAEMON_C_
#define EXTERN
#else
#define EXTERN  extern
#endif

/*
 *  Funktionen
 */

#if defined (__STDC__) 
  /*
   * ANSI C 
   */
  EXTERN int         change_to_daemon(const char*,const char*,int);

#else
  /*
   * Traditional C
   */
  EXTERN int         change_to_daemon();

#endif


#undef EXTERN
#endif  /* _SYSDEP_DAEMON_H_ */

/*
 *  Ende 'daemon.h'
 */
