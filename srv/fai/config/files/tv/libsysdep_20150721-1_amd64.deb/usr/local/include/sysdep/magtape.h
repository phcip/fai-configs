/*
 *  magtape.h                   (R.Wirowski IKP Uni-Koeln 10-Apr-1992)
 *  ---------
 *
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: magtape.h,v 1.1 1994/05/26 09:19:00 rw Exp rw $
 *
 *  $Log: magtape.h,v $
 * Revision 1.1  1994/05/26  09:19:00  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_MAGTAPE_H_
#define _SYSDEP_MAGTAPE_H_

#ifdef _SYSDEP_MAGTAPE_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/*
 *  Definitionen fuer 'magtape_cmd()'
 */

#define  MAGTAPE_WEOF    (0)
#define  MAGTAPE_FSF     (1)
#define  MAGTAPE_BSF     (2)
#define  MAGTAPE_OFFL    (3)
#define  MAGTAPE_REW     (4)

/*
 *  Globale Funktionen
 */

#ifdef __STDC__
  /*
   * ANSI C 
   */
  EXTERN int          is_magtape(int);
  EXTERN int          magtape_cmd(int,int,...);
  EXTERN void         add_magtape_error(int);
  EXTERN const char   *magtape_errfmt(int);

#else  
  /*
   * Traditional C
   */
  EXTERN int          is_magtape();
  EXTERN int          magtape_cmd();
  EXTERN void         add_magtape_error();
  EXTERN const char   *magtape_errfmt();

#endif




#undef EXTERN
#endif  /* _SYSDEP_MAGTAPE_H_ */

/*
 *  Ende magtape.h
 */
