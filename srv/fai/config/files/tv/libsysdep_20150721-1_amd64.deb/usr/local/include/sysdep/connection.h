/*
 *  connection.h: Raw buffer transport mechanism (Header file)
 *
 *  Part of libsysdep.a
 *
 *  Author: N. Nicolay
 *
 *  First Version: (1.0)       23-AUG-93
 *
 *  $Id: connection.h,v 1.10 1993/10/14 14:53:49 nicolay Working nicolay $
 *
 *  $Log: connection.h,v $
 * Revision 1.10  1993/10/14  14:53:49  nicolay
 * Working version
 *
 * Revision 1.9  1993/10/14  14:42:32  nicolay
 * Just showed rcs usage to Olli
 *
 * Revision 1.8  1993/10/14  14:39:36  nicolay
 * Code cleaned up, included definitions for ANSI C
 *
 * Revision 1.7  1993/10/14  12:50:12  nicolay
 * Reliable messages over the internet works.
 * TODO: local connections and htonl implementation
 *
 * Revision 1.6  1993/10/11  12:42:40  nicolay
 * Test of the Log flag
 *
 */

#ifndef _SYSDEP_CONNECTION_H_
#define _SYSDEP_CONNECTION_H_

#include <sys/types.h>
#include <sys/un.h>
#include <netinet/in.h>

#ifdef _SYSDEP_CONNECTION_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/* mode flags */
#define CN_LOCAL_HOST              ((char *) -1)
#define CN_FLAG_DEFAULT            000
#define CN_FLAG_SERVICE_BY_NAME    000
#define CN_FLAG_SERVICE_BY_PORT    001
#define CN_FLAG_RELIABLE           002
#define CN_FLAG_LOCAL_SERVICE      004

/* defaults */
#define CN_DEFAULT_TIMEOUT      4
#define CN_LOCAL_PATH_LEN      16
#define CN_LOCAL_PATH_NAME     "/tmp/cnXXXXXXX"
#define CN_LINGER_TIME          5

/* errors */
#define CN_SERIOUS_ERROR       (-1)
#define CN_TIMEOUT_ERROR       (-2)
#define CN_OUTOFSYNC_ERROR     (-3)

typedef struct __connection {
  int                  sd;         /* socket descriptor */
  int                  local;      /* local or internet flag */
  int                  reliable;   /* reliable connection flag */
  int                  is_server;  /* process is server flag */
  int                  sock_open;  /* flag if socket is opened */
  char                *servername; /* name of connected server */
  union 
    {
      struct sockaddr_un loc;
      struct sockaddr_in net;
    } cli, srv;                    /* client and server addresses */
  int                  saddrlen;   /* address lenght server */
  int                  caddrlen;   /* address length client */
  int                  timeout;    /* timeout value */
  struct __connection *next_connection;
} CONNECTION;

typedef struct __service {
  int                  sd;
  int                  local;
  int                  reliable;
  union 
    {
      struct sockaddr_un loc;
      struct sockaddr_in net;
    } cli, srv;
  int                  caddrlen;
  int                  saddrlen;
  int                  clisize;
  int                  accepted;
  struct __service    *next_service;
} SERVICE;

/* Functions available in this library module */

#if defined(__STDC__)

/* functions used by client & server */
EXTERN CONNECTION *open_connection(char *host, int mode, ...);
EXTERN int         set_timeout(CONNECTION *cn, int count);
EXTERN int         send_connection(CONNECTION *cnc, void *buffer, int size);
EXTERN int         recv_connection(CONNECTION *cnc, void *buffer, int *size, 
				   int maxsize);
EXTERN int         close_connection(CONNECTION *cn);
EXTERN int         close_all_connections(void);

/* functions used by servers */
EXTERN SERVICE    *add_service(int mode, ...);
EXTERN int         remove_service(SERVICE *s);
EXTERN int         remove_all_services(void);
EXTERN CONNECTION *wait_connection(void);

#else

/* functions used by client & server */
EXTERN CONNECTION *open_connection();
EXTERN int         set_timeout();
EXTERN int         send_connection();
EXTERN int         recv_connection();
EXTERN int         close_connection();
EXTERN int         close_all_connections();

/* functions used by servers */
EXTERN SERVICE    *add_service();
EXTERN int         remove_service();
EXTERN int         remove_all_services();
EXTERN CONNECTION *wait_connection();

#endif
#endif
