/*
 *  date.h                   (IKP Uni-Koeln 10-May-1992)
 *  ------
 *
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: date.h,v 1.1 1994/05/26 09:17:02 rw Exp rw $
 *
 *  $Log: date.h,v $
 * Revision 1.1  1994/05/26  09:17:02  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_DATE_H_
#define _SYSDEP_DATE_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_DATE_H_
#include <sysdep/date.h>
#endif
#endif

#ifdef _SYSDEP_DATE_C_
#define EXTERN
#else
#define EXTERN extern
#endif


/*
 *  Globale Funktionen
 */

#if defined (__STDC__) && !defined (OSK) 
  /*
   * ANSI C 
   */
  EXTERN const char   *date_time();
  EXTERN int          is_leapyear(int);
  EXTERN const char   *date_to_string(int,int);
  EXTERN int          days_of_month(int,int);

#else
  /*
   * Traditional C
   */
  EXTERN const char   *date_time();
  EXTERN int          is_leapyear();
  EXTERN const char   *date_to_string();
  EXTERN int          days_of_month();

#endif


/*
 *  Makros
 */





#undef EXTERN
#endif  /* _DATE_PRINT_H_ */

/*
 *  Ende 'date.h'
 */
