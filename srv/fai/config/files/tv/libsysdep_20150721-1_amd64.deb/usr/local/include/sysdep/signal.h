/*
 *  signal.h                   (R.Wirowski IKP Uni-Koeln 08-Apr-1992)
 *  ---------
 *
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: signal.h,v 1.1 1994/05/26 09:21:16 rw Exp rw $
 *
 *  $Log: signal.h,v $
 * Revision 1.1  1994/05/26  09:21:16  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_SIGNAL_H_
#define _SYSDEP_SIGNAL_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_CONFIG_H_
#include <sysdep/config.h>
#endif
#endif

#ifdef _SYSDEP_SIGNAL_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/*
 *  Typedeklararionen
 */

typedef struct __signal_handler {
  int                         sig_no;
#ifdef HAVE_SIGVEC
  int                         sig_mask;
  struct sigvec               new;
  struct sigvec               old;
  int                         blocked_mask;
#else
#ifdef HAVE_SIGACTION
  sigset_t                    sig_mask;
  struct sigaction            new;
  struct sigaction            old;
  sigset_t                    blocked_mask;
#endif /* HAVE_SIGACTION */
#endif /* HAVE_SIGVEC    */
  int                         (*wait_f)();
  struct __signal_handler     *next_signal_handler;
} SIGNAL_HANDLER;


/*
 *  Globale Funktionen
 */

#if defined (__STDC__) && !defined (OSK) 
  /*
   * ANSI C 
   */
  EXTERN SIGNAL_HANDLER   *define_signal_handler(int,void(*)(),int(*)());
  EXTERN void             wait_for_signal(SIGNAL_HANDLER*);
  EXTERN int              send_signal(int,int);
  EXTERN void             block_signal_handler(SIGNAL_HANDLER*,int,...);
  EXTERN void             unblock_signal_handler(SIGNAL_HANDLER*);
  EXTERN int              revoke_signal_handler(SIGNAL_HANDLER*);
  EXTERN int              delete_signal(int);

#else  
  /*
   * Traditional C
   */
  EXTERN SIGNAL_HANDLER   *define_signal_handler();
  EXTERN void             wait_for_signal();
  EXTERN int              send_signal();
  EXTERN void             block_signal_handler();
  EXTERN void             unblock_signal_handler();
  EXTERN int              revoke_signal_handler();
  EXTERN int              delete_signal();

#endif


/*
 *  Makros
 */

#if defined(HAVE_KILL) && !defined(_SYSDEP_SIGNAL_C_)
#define  send_signal(_pid,_sig)     kill(_pid,_sig)
#endif

#undef EXTERN
#endif  /* _SYSDEP_SIGNAL_H_ */

/*
 *  Ende signal.h
 */
