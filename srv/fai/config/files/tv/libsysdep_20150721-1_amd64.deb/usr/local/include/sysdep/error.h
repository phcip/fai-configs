/*
 *  error.h                   (R.Wirowski IKP Uni-Koeln 21-Apr-1993)
 *  -------
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: error.h,v 1.1 1994/05/26 09:17:42 rw Exp rw $
 *
 *  $Log: error.h,v $
 * Revision 1.1  1994/05/26  09:17:42  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_ERROR_H_
#define _SYSDEP_ERROR_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_ERROR_C_
#define EXTERN
#else
#define EXTERN extern
#endif


/*
 *  Typdeklarationen
 */

typedef struct __error {
  int              mode;
  time_t           time;
  const char       *modul;     
  const char       *message;
  struct __error   *next_error;
} ERROR;


/*
 *  Funktionsdeklarationen:
 */

#if defined (__STDC__)
  /*
   * ANSI C
   */
  EXTERN void            add_error(int,const char*,const char*,...);
  EXTERN void            vadd_error(int,const char*,const char*,va_list);
  EXTERN int             error_level(void);
  EXTERN int             error_attributes(int);
  EXTERN ERROR           *get_error(int);
  EXTERN void            print_error(int);
  EXTERN void            free_error(int);

#else  
  /*
   * Traditional C
   */
  EXTERN void            add_error();
  EXTERN void            vadd_error();
  EXTERN int             error_level();
  EXTERN int             error_attributes();
  EXTERN ERROR           *get_error();
  EXTERN void            print_error();
  EXTERN void            free_error();

#endif


/*
 *  Makros  
 */

#define  MAX_ERROR_STRING        (1024)


/*
 *  Makros fuer 'add_error()' und 'vadd_error()'
 */

#define  ERROR_STRING            (1)
#define  ERROR_STATIC            (2)
#define  ERROR_FORMATTED         (3)
#ifdef _LIBRARY_A_
#define  ERROR_TRANSPORT         (4)     /* don't use it in a user program */
#endif

/*
 *  Makros fuer 'error_attributes'
 */

#define  ERROR_LEVEL             (0001)
#define  ERROR_TIME              (0002)

/*
 *  Makros fuer 'print_error()'
 */

#define  ERROR_STACK             (1)
#define  ERROR_LAST              (2)

/*
 *  Makros fuer 'free_error()'
 */

#define  ERROR_ALLLEVELS         (-1)



#undef EXTERN
#endif  /* _SYSDEP_ERROR_H_ */
  
/*
 *  Ende 'error.h'
 */

	

