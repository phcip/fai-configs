/*
 *  file.h                   (R.Wirowski IKP Uni-Koeln 15-Sep-1992)
 *  -------
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: file.h,v 1.1 1994/05/26 09:18:34 rw Exp rw $
 *
 *  $Log: file.h,v $
 * Revision 1.1  1994/05/26  09:18:34  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_FILE_H_
#define _SYSDEP_FILE_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_CONFIG_H_
#include <sysdep/config.h>
#endif
#endif

#ifdef _SYSDEP_FILE_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/*
 *  Funktionsdeklarationen:
 */

#if defined (__STDC__)
  /*
   * ANSI C
   */
  EXTERN int            create_empty_file(char*,int,int);
  EXTERN void           prepend_to_filename(char*,char*,char*);
  EXTERN char           *base_filename(char*);
  EXTERN void           build_filename(char*,...);
  EXTERN void           vbuild_filename(char*,va_list);
  EXTERN char           *vget_filename(va_list);
  EXTERN int            max_open_files(void);
  EXTERN int            adjust_file_offset(int);
#ifdef LIMITED_FILE_OFFSET
  EXTERN int            adjust_file_offset_after_error(int,int);
#endif

#else  
  /*
   * Traditional C
   */
  EXTERN int            create_empty_file();
  EXTERN void           prepend_to_filename();
  EXTERN char           *base_filename();
  EXTERN void           build_filename();
  EXTERN void           vbuild_filename();
  EXTERN char           *vget_filename();
  EXTERN int            max_open_files();
  EXTERN int            adjust_file_offset();
#ifdef LIMITED_FILE_OFFSET
  EXTERN int            adjust_file_offset_after_error();
#endif

#endif

/*
 *  Gloable Variablen
 */

#ifdef _SYSDEP_FILE_C_
#if defined(vms) && !defined(vms_posix)
         char          null_device[] = "NLA0:";
#else
         char          null_device[] = "/dev/null";
#endif
#else
  extern char          null_device[];
#endif



/*
 *  Makrodefinitionen
 */

#define  MAX_FILENAME           (256)

/*
 *  I/O Buffergroessen in Bytes
 */

#define  BUFFER_SIZE            (8192)         
#define  DISK_BUFFER_SIZE       BUFFER_SIZE
#define  PIPE_BUFFER_SIZE       BUFFER_SIZE
#define  TAPE_BUFFER_SIZE       BUFFER_SIZE
#define  MAX_BUFFER_SIZE        (65536)

#define  PMODE                  (0644)

/*
 *  funktionsartige Makrodefinitionen
 */

#define read16(fd,buf,nw)       (read(fd,(char*)(buf),(nw)<<1)>>1)
#define write16(fd,buf,nw)      (write(fd,(char*)(buf),(nw)<<1)>>1)
#define has_wildcards(fn)       (strchr(fn,FILE_WILDCARD)!=NULL)


#undef EXTERN
#endif  /* _SYSDEP_FILE_H_ */
  
/*
 *  Ende 'file.h'
 */

	



