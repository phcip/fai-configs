/*
 *  bits.h                   (R.Wirowski IKP Uni-Koeln 31-Apr-1991)
 *  ------
 *
 *  Header-File fuer Programme, die die Bit-Operationsroutinen
 *  der rw-Library benutzen. Muss in Anwenderprogrammen
 *  'include't werden.
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: bits.h,v 1.1 1994/05/26 09:12:54 rw Exp rw $
 *
 *  $Log: bits.h,v $
 * Revision 1.1  1994/05/26  09:12:54  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_BITS_H_
#define _SYSDEP_BITS_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_BITS_C_
#define EXTERN
#else
#define EXTERN extern
#endif

/*
 *  Funktionsdeklarationen
 */

#if defined (__STDC__) && !defined (OSK)
  /*
   *  Ansi-C
   */
  EXTERN unsigned count_bits(UINT32);                 
  EXTERN int      lowest_bit(unsigned);                  
  EXTERN int      highest_bit(unsigned);                
  EXTERN int      *ini_lowest_bit_table(int);       
  EXTERN int      *ini_highest_bit_table(int);      

#else  /* __STDC__ */
  /*
   *  Traditional-C
   */
  EXTERN unsigned count_bits();                 
  EXTERN int      lowest_bit();                  
  EXTERN int      highest_bit();                
  EXTERN int      *ini_lowest_bit_table();       
  EXTERN int      *ini_highest_bit_table();      

#endif  /* __STDC__ */

/*
 * Makrodefinitionen:
 */

#define set_bit(_word,_bit)       ( (_word) |= (1<<(_bit)) )
#define test_bit(_word,_bit)      ( (_word) &  (1<<(_bit)) )
#define set_bits(_no)             ( (1<<(_no))-1 )
#define reset_bit_table(_table)   ( free((void*)(_table)) )



#undef EXTERN
#endif  /* _SYSDEP_BITS_H_ */

/*
 *  Ende 'bits.h'
 */
