/*
 *  config.h                   (IKP Uni-Koeln 02-Feb-1993)
 *  --------
 *
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: config.h,v 1.8 1999/04/15 01:16:22 root Exp $
 *
 *  $Log: config.h,v $
 * Revision 1.8  1999/04/15  01:16:22  root
 * *** empty log message ***
 *
 * Revision 1.8  1999/04/15  01:16:22  root
 * *** empty log message ***
 *
 * Revision 1.7  1996/11/28  14:35:04  nicolay
 * Adaption for Solaris done.
 *
 * Revision 1.6  1995/09/20  14:26:43  rw
 * Ported to NetBSD (N. Nicolay)
 *
 * Revision 1.5  1994/12/01  14:31:21  rw
 * New macro HAVE_VME_MEM implemented for systems whic support external
 * raw VME memory.
 *
 * Revision 1.4  1994/09/16  10:50:00  rw
 * config.h for Linux changed: Linux doesn't need SHM_QUANTUM
 * (N. Nicolay)
 *
 * Revision 1.3  1994/09/01  09:25:50  rw
 * Wrong entry BIG_ENDIAN in the Linux part of the configuration file removed.
 * (Norbert Nicolay)
 *
 * Revision 1.2  1994/05/26  12:23:06  rw
 * libsysdep.a ported to Linux (N. Nicolay)
 *
 * Revision 1.1  1994/05/26  09:15:14  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_CONFIG_H_
#define _SYSDEP_CONFIG_H_

/*
 *  Betriebssystem abhaengige Definitionen:
 *  ---------------------------------------
 *
 *  BIG_ENDIAN            = hpux, sun ,680x0, Z8000, ...
 *                          ( opposite: LITTLE_ENDIAN=dec vax, dec R3000, ... )
 *  BSD                   = 
 *  SYSV                  =
 *  HAVE_SIGVEC           = 'sigvec()'-Call vorhanden (bei BSD-Systemen)
 *  HAVE_SIGACTION        = 'sigaction()'-Call vorhanden (bei Posix-Systemen)
 *                          Einer der beiden Moeglichkeiten muss gesetzt sein.
 *  INT_SIGHANDLER        = 'int'-Signal-Handler
 *  HAVE_KILL             = 'kill()'-Call vorhanden
 *  WRITES_CORE_FILE      = System kann bei Fehler 'core'-File schreiben
 *  HAVE_VOLATILE         = 'volatile'-Datentyp bei nicht ANSI-C
 *  HAVE_SIGNED		  = 'signed'-Datentype bei nicht ANSI-C
 *  HAVE_CONST            = 'const'-Datentyp bei nicht ANSI-C
 *  HAVE_VFORK            = virtuelles fork
 *  HAVE_RLIMIT           = 'getrlimit()'- und 'setrlimit()'-Calls vorhanden
 *  HAVE_GETDTABLESIZE    = 'getdtablesize()'-Call vorhanden
 *  HAVE_MTIO             = magnetic tape interface
 *  HAVE_SYSV_SHM	  = System-V shared memory
 *  HAVE_POSIX_SHM	  = Posix shared memory
 *  SHM_QUANTUM=XXXX      = Shared memory Speicherplatz wird intern in einem 
 *                          Vielfachen von 'XXXX' allociert und dieses
 *                          Vielfache wird auch bei System-V shared memory
 *                          als 'buf.shm_segsz' bei 'shmctl(id,IPC_STAT,&buf)'
 *                          anstelle des angeforderten Wertes herausgegeben 
 *                          (z.B. 4096 bei LynxOS). Bei Posix wird ebenso 
 *                          dieses Vielfache bei 'stat()' angezeigt.
 *  HAVE_PLOCK            = locking of process in memory
 *  HAVE_VALLOC           = malloc with alignment on begin of page 
 *  HAVE_GLOBAL_VADVISE   = global change of paging behaviour
 *  HAVE_PER_PAGE_VADVISE = per page change of paging behaviour
 *  HAVE_CACHECTL         = control of cache (on/off) for memory region
 *  LIMITED_FILE_OFFSET   = File-Offset limitert das Einlesen groessere
 *                          Files von Tape oder Pipe. Auf vielen Architekturen
 *                          ist der File-offset im Kernel nur signed int, d.h.
 *                          man kann nicht mehr, wie 2^31 Bytes ~ 2GByte lesen.
 *  HAVE_SENDMSG          = das Betriebssystem unterstuetzt die sendmsg/recvmsg
 *                          calls auf BSD sockets
 */


/*
 *  Ultrix 
 */

#ifdef ultrix
#define OPERATION_SYSTEM "Ultrix"

#define BSD
#define HAVE_VOLATILE
#define HAVE_SIGNED
#define HAVE_SIGVEC
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_VFORK
#define HAVE_RLIMIT
#define HAVE_GETDTABLESIZE
#define HAVE_MTIO
#define HAVE_SYSV_SHM
#define HAVE_QSORT
#define HAVE_PLOCK
#define HAVE_GLOBAL_VADVISE
#ifdef mips
#if 0
#define HAVE_CACHECTL
#endif
#endif
#define LIMITED_FILE_OFFSET
#define HAVE_SENDMSG
#endif /* ultrix */

/*
 *  AXP/OSF
 */

#if defined(__osf__) && defined(__alpha) 
#define OPERATION_SYSTEM "AXP/OSF"

#define BSD
#define HAVE_VOLATILE
#define HAVE_SIGNED
#define HAVE_SIGVEC
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_VFORK
#define HAVE_RLIMIT
#define HAVE_GETDTABLESIZE
#define HAVE_MTIO
#define HAVE_SYSV_SHM
#define HAVE_QSORT
#define HAVE_PLOCK
#define HAVE_GLOBAL_VADVISE
#define LIMITED_FILE_OFFSET
#define HAVE_SENDMSG

#endif /* AXP/OSF */


/*
 *  SunOS
 */

#ifdef sun
#define OPERATION_SYSTEM "SunOS"

#if defined(__SVR4)
/* Solaris */

/* #define HAVE_SIGVEC */
#define HAVE_SIGACTION
#define VOID_SIGHANDLER
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_RLIMIT
#define HAVE_GETDTABLESIZE
#define HAVE_MTIO
#define HAVE_SYSV_SHM
#define BIG_ENDIAN
#define HAVE_QSORT
#define HAVE_PLOCK
#define HAVE_SENDMSG

#else

#define BSD
#define HAVE_SIGVEC
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_VFORK
#define HAVE_RLIMIT
#define HAVE_GETDTABLESIZE
#define HAVE_MTIO
#define HAVE_SYSV_SHM
#define HAVE_GLOBAL_VADVISE
#define HAVE_QSORT
#define HAVE_PLOCK
#define BIG_ENDIAN
#define LIMITED_FILE_OFFSET
#define HAVE_SENDMSG
#endif
#endif /* sun */

/*
 * NetBSD
 */
#ifdef __NetBSD__
#define OPERATION_SYSTEM "NetBSD"

#define BSD
#define HAVE_SIGVEC
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_VFORK
#define HAVE_RLIMIT
#define HAVE_GETDTABLESIZE
#define HAVE_MTIO
#define HAVE_SYSV_SHM
#define HAVE_QSORT
#define HAVE_PLOCK
#if !defined(BIG_ENDIAN)
#define BIG_ENDIAN
#endif

#endif /* sun */


/*
 *  HP-UX
 */

#ifdef hpux
#define OPERATION_SYSTEM "HP-UX"

#define BSD
#define HAVE_VOLATILE
#define HAVE_SIGVEC
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_VFORK
#define HAVE_MTIO
#define HAVE_SYSV_SHM
#define HAVE_QSORT
#define HAVE_PLOCK
#define BIG_ENDIAN
#define LIMITED_FILE_OFFSET
#define HAVE_SENDMSG

#endif /* hpux */

/*
 *  LynxOS
 */

#ifdef Lynx
#define OPERATION_SYSTEM "LynxOS"

#define BSD
/* #define HAVE_SIGVEC */
#define HAVE_SIGACTION
#define VOID_SIGHANDLER
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_RLIMIT
#define HAVE_GETDTABLESIZE
#define HAVE_SYSV_SHM
/* #define HAVE_POSIX_SHM */
#define SHM_QUANTUM             (4096)
#define HAVE_QSORT
#define BIG_ENDIAN
#define LIMITED_FILE_OFFSET
#define HAVE_SENDMSG
#if defined(M68K) || defined(__powerpc__)
#define HAVE_VME_MEMORY
#endif

#endif /* Lynx */


/*
 *  VMS
 */

#if defined(vms) && !defined(vms_posix)
#define OPERATION_SYSTEM "VMS"

#endif /* vms */


/*
 *  VMS-Posix
 */

#if defined(vms) && defined(vms_posix)
#define OPERATION_SYSTEM "VMS-Posix"

#define HAVE_SIGACTION
#define HAVE_KILL
#define HAVE_POSIX_SHM

#endif /* vms_posix */


#if defined(linux)
#define OPERATION_SYSTEM "Linux"

/* #define BSD */
/* #define HAVE_SIGVEC */
#define HAVE_SIGACTION
#define VOID_SIGHANDLER
#define HAVE_KILL
#define WRITES_CORE_FILE
#define HAVE_RLIMIT
#define HAVE_GETDTABLESIZE
#define HAVE_SYSV_SHM
/* #define HAVE_POSIX_SHM */
/* #define SHM_QUANTUM             (4096) */
#define HAVE_QSORT
#define LIMITED_FILE_OFFSET
#undef BIG_ENDIAN
#endif

/*
 *  Einige Plausibilitaetsueberpruefungen
 */

/*
 * #ifndef OPERATION_SYSTEM
 *  ERROR: "Kein Operations-System definiert."
 * #endif
 *
 * #if defined(HAVE_SHM)   
 *  ERROR: Shared Memory darf nicht global angegeben werden.
 * #endif
 *
 * #if defined(SHM_QUANTUM) && !defined(HAVE_SYSV_SHM) && !defined(HAVE_POSIX_SHM)
 *  ERROR: Shared Memory Quantum ohne Shared Memory Art angegeben.
 * #endif
 *
 * #if defined(HAVE_SIGVEC) && defined(HAVE_SIGACTION) 
 *  ERROR: Beide Arten von Signalbehandlung nicht gleichzeitig moeglich.
 * #endif
 */

/*
 *  Automatische Generierung zusaetzlicher Makros
 */

#if defined(HAVE_SYSV_SHM) || defined(HAVE_POSIX_SHM)
#define HAVE_SHM
#endif 


#endif

/*
 *  Ende 'config.h'
 */

