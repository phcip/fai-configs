/*
 *  types.h                   (IKP Uni-Koeln 19-May-1992)
 *  -------
 *
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: types.h,v 1.1 1994/05/26 09:24:08 rw Exp nicolay $
 *
 *  $Log: types.h,v $
 * Revision 1.1  1994/05/26  09:24:08  rw
 * Initial revision
 *
 *
 *
 */

#ifndef _SYSDEP_TYPES_H_
#define _SYSDEP_TYPES_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_CONFIG_H_
#include <sysdep/config.h>
#endif
#endif

#ifndef __STDC__
#if !defined(HAVE_CONST) && !defined(const)
#define const     /*nothing*/
#endif
#if !defined(HAVE_VOLATILE) && !defined(volatile)
#define volatile  /*nothing*/
#endif
#if !defined(HAVE_SIGNED) && !defined(signed)
#define signed   /*nothing*/
#endif
#endif /* __STDC__ */

/*
 *  Typedeklarationen
 */

#ifndef _TYPE_UINT8_
typedef  unsigned char         UINT8;
#define _TYPE_UINT8_
#endif

#ifndef _TYPE_UINT16_
typedef  unsigned short        UINT16;
#define _TYPE_UINT16_
#endif

#ifndef _TYPE_UINT32_
#if defined(__alpha) || defined(__mips64)
typedef  unsigned int          UINT32;
#else
typedef  unsigned long         UINT32;
#endif
#define _TYPE_UINT32_
#endif

#ifndef _TYPE_INT8_
typedef  signed char           INT8;
#define _TYPE_INT8_
#endif

#ifndef _TYPE_INT16_
typedef  signed short          INT16;
#define _TYPE_INT16_
#endif

#ifndef _TYPE_INT32_
#if defined(__alpha) || defined(__mips64)
typedef  signed int            INT32;
#else
typedef  signed long           INT32;
#endif
#define _TYPE_INT32_
#endif

#ifndef _TYPE_FLAG_
typedef  int                   FLAG;
#define _TYPE_FLAG_
#endif

/*
 *  Makros
 */

#ifndef FALSE
#define  FALSE                 (0)
#endif
#ifndef TRUE
#define  TRUE                  (1)
#endif

#undef EXTERN
#endif  /* _SYSDEP_TYPES_H_ */

/*
 *  Ende 'types.h'
 */
