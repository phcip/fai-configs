/*
 *  cpu_time.h                   (R.Wirowski IKP Uni-Koeln 31-Apr-1991)
 *  ----------
 *
 *  Letzte Aenderung:
 *  -----------------
 *
 *  $Id: cpu_time.h,v 1.1 1994/05/26 09:16:00 rw Exp rw $
 *
 *  $Log: cpu_time.h,v $
 * Revision 1.1  1994/05/26  09:16:00  rw
 * Initial revision
 *
 *
 *
 *
 */

#ifndef _SYSDEP_CPU_TIME_H_
#define _SYSDEP_CPU_TIME_H_

#ifndef _LIBRARY_A_
#endif

#ifdef _SYSDEP_CPU_TIME_C_
#define EXTERN
#else
#define EXTERN  extern
#endif

/*
 *  Funktionen:
 */

#if defined (__STDC__) && !defined (OSK)
  /*
   * ANSI C 
   */
  EXTERN int      cpu_time(double*);

#else 
  /*
   * Traditional C
   */
  EXTERN int      cpu_time();

#endif


#undef EXTERN

#endif  /* _SYSDEP_CPU_TIME_H_ */

/*
 *  Ende 'cpu_time.h'
 */



