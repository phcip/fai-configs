/*
 *  process.h                   (R.Wirowski IKP Uni-Koeln 05-Oct-1992)
 *  ---------
 *
 *
 *  $Id: process.h,v 1.1 1994/05/26 09:20:26 rw Exp rw $
 *
 *  $Log: process.h,v $
 * Revision 1.1  1994/05/26  09:20:26  rw
 * Initial revision
 *
 *
 *
 *
 */

#ifndef _SYSDEP_PROCESS_H_
#define _SYSDEP_PROCESS_H_

#ifndef _LIBRARY_A_
#ifndef _SYSDEP_TYPES_H_
#include <sysdep/types.h>
#endif
#endif

#ifdef _SYSDEP_PROCESS_C_
#define EXTERN
#else
#define EXTERN  extern
#endif


/*
 *  Typedeklarationen
 */

typedef struct __process {
  int                  mode;
  char                 *image;
  pid_t                pid;
  int                  fd[3];
  volatile int         status;
#ifdef __STDC__
  int                  (*term_f)(struct __process*);
#else
  int                  (*term_f)();
#endif
  struct __process     *next_process;
} PROCESS;


/*
 *  Funktionen
 */

#if defined (__STDC__) 
  /*
   * ANSI C 
   */
  EXTERN PROCESS     *spawn_process(int,int*,int*,int*,...);
  EXTERN PROCESS     *vspawn_process(int,int*,int*,int*,...);
  EXTERN int         kill_process(PROCESS*);
  EXTERN int         process_wait(PROCESS*,int(*)(PROCESS*));
  EXTERN int         system_process(const char*,...);
  EXTERN int         has_subprocesses(void);

#else
  /*
   * Traditional C
   */
  EXTERN PROCESS     *spawn_process();
  EXTERN PROCESS     *vspawn_process();
  EXTERN int         kill_process();
  EXTERN int         process_wait();
  EXTERN int         system_process();
  EXTERN int         has_subprocesses();

#endif

/*
 *  Makros fuer 'std_xxx' in 'spawn_process()'
 */

#define DESCRIPTOR_CLOSE        (((int*)0)-1)
#define DESCRIPTOR_DEVNULL      (((int*)0)-2)
#define DESCRIPTOR_KEEPOPEN     (((int*)0)-3)

/*
 *  Makros fuer 'mode' in 'spawn_process()'
 */

#define TERMINATION_MASK        (00017)
#define TERMINATION_RECOGNIZE   (00001)
#define TERMINATION_ABORT       (00002)
#define TERMINATION_IGNORE      (00004)
#define TERMINATION_FUNCTION    (00010)

#define ARGUMENT_VECTOR         (00100)

/*
 *  Makro fuer 'process_status()'
 */

#define PROCESS_RUNNING         (1)
#define PROCESS_TERMINATED      (2)
#define PROCESS_EXITED          (3)  

/*
 *  Makros
 */

#define process_status(p)      ((p)->status)
#define process_id(p)          ((int)((p)->pid))

#undef EXTERN
#endif  /* _SYSDEP_PROCESS_H_ */

/*
 *  Ende 'process.h'
 */
